import 'package:flutter/material.dart';
import 'package:hac/models/user.dart';
import 'package:hac/services/auth.dart';
import 'package:hac/screens/profilepage/profile.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:hac/sideDrawer.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final AuthService _authService = AuthService();

  final firestoreInstance = Firestore.instance;

  String _name = '';
  String _address = '';
  String _mainarea = '';
  String _phoneno = '';

  final FirebaseAuth _auth = FirebaseAuth.instance;
  FirebaseUser user;

  @override
  void initState() {
    super.initState();
    initUser();
  }

  initUser() async {
    user = await _auth.currentUser();
    firestoreInstance
        .collection("Users")
        .document(user.uid)
        .get()
        .then((value) {
      print(value.data);
      // var _list = [];
      // value.data.forEach((k, v) => _list.add(v));

      setState(() {
        _name = value['Name'];
        _address = value['Address'];
        _mainarea = value['Main Area'];
        _phoneno = value['Phone Number'];
      });
    });
    // setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // print('from Home page');
    // print('$name, $address, $mainarea, $phoneno');
    return Container(
        child: Scaffold(
      backgroundColor: Colors.green[50],
      drawer: SideDrawer(
        name: _name,
        address: _address,
        mainarea: _mainarea,
        phoneno: _phoneno,
      ),
      appBar: AppBar(
        title: Text('Home'),
        backgroundColor: Colors.green[400],
        elevation: 0.0,
        actions: <Widget>[
          FlatButton.icon(
              onPressed: () async {
                _authService.phoneSignOut(context);
              },
              icon: Icon(Icons.person),
              label: Text('LOGOUT')),
        ],
      ),
      body: Center(
          child: Column(
        children: <Widget>[
          SizedBox(
            height: 250,
          ),
          SizedBox(
            child: Column(
              children: <Widget>[
                Text('This is HOME'),
              ],
            ),
          )
        ],
      )),
    ));
  }
}
